/* corpus/20000205-1.c */
static int f (int a)
{
  if (a == 0)
    { return 0; }
  do
    if (a & 128)
    { return 1; }
  while (f (0));
  return 0;
}

int main(void)
{
  if (f (~128))
    { abort (); }
  exit (0);
}
/* ProgramSourceLLVM */
